import { DefectRecord, SessionSummary } from '../types';
import { getBaseCategory } from './parser';

export type NormalizationMode = 'DEDUP_MAX' | 'PROPORTIONAL' | 'RAW';

export interface CategorySummaryRecord {
  camera: string;
  category: string;
  ngBox: string;
  rawQty: number;
  dedupMaxQty: number;
  proportionalQty: number;
  effectiveQty: number;
  subItemCount: number;
  subItems: DefectRecord[];
}

export interface BinReconciliationSummary {
  lotNumber: string;
  totalNg: number;
  bins: {
    [box: string]: {
      hardwareCount: number;
      rawSum: number;
      dedupMaxSum: number;
      proportionalSum: number;
    };
  };
}

/**
 * Normalizes defect records across lots according to the chosen NormalizationMode:
 * - DEDUP_MAX (Default): Sub-parameters measuring the same physical defect (e.g. Area, Total Area, X, Y)
 *   are deduplicated using Math.max() per lot so the same part is not counted 3-4 times.
 *   Category max is capped by the hardware bin count.
 * - PROPORTIONAL: Categories are scaled so the sum in each bin matches the exact hardware bin total (NG1, NG2, NG3, RST)
 *   reported in the CSV header. Total Category Rejects will equal Total Calculated NG.
 * - RAW: Direct raw additive counts from individual test item lines.
 */
export function normalizeDefectsList(
  defects: DefectRecord[],
  sessions: SessionSummary[],
  mode: NormalizationMode = 'DEDUP_MAX'
): DefectRecord[] {
  if (defects.length === 0) return [];
  if (mode === 'RAW') {
    return defects.map(d => ({
      ...d,
      rawNgQty: d.rawNgQty ?? d.ngQty,
      normalizedNgQty: d.rawNgQty ?? d.ngQty,
      ngQty: d.rawNgQty ?? d.ngQty,
    }));
  }

  // Group defects by lotNumber
  const sessionMap = new Map<string, SessionSummary>();
  sessions.forEach(s => {
    if (s.lotNumber) sessionMap.set(s.lotNumber, s);
  });

  const defectsByLot = new Map<string, DefectRecord[]>();
  defects.forEach(d => {
    const lot = d.lotNumber || '-';
    if (!defectsByLot.has(lot)) defectsByLot.set(lot, []);
    defectsByLot.get(lot)!.push(d);
  });

  const normalizedResults: DefectRecord[] = [];

  for (const [lot, lotDefects] of defectsByLot.entries()) {
    const session = sessionMap.get(lot);
    const binTotals: Record<string, number> = {
      NG1: session?.ng1Qty || 0,
      NG2: session?.ng2Qty || 0,
      NG3: session?.ng3Qty || 0,
      RST: session?.retestQty || 0,
    };

    // Group defects in this lot by: camera + '::' + baseCategory
    const groups = new Map<string, {
      camera: string;
      baseCat: string;
      ngBox: string;
      records: DefectRecord[];
      rawSum: number;
      maxQty: number;
    }>();

    lotDefects.forEach(d => {
      const baseCat = d.baseCategory || getBaseCategory(d.testItem);
      const key = `${d.camera}::${baseCat}`;
      if (!groups.has(key)) {
        groups.set(key, {
          camera: d.camera,
          baseCat,
          ngBox: d.ngBox || 'NG1',
          records: [],
          rawSum: 0,
          maxQty: 0,
        });
      }
      const g = groups.get(key)!;
      g.records.push(d);
      const rawVal = d.rawNgQty ?? d.ngQty;
      g.rawSum += rawVal;
      if (rawVal > g.maxQty) {
        g.maxQty = rawVal;
      }
    });

    // Clamp category max to bin total if known
    for (const g of groups.values()) {
      const binCap = binTotals[g.ngBox];
      if (binCap !== undefined && binCap > 0 && g.maxQty > binCap) {
        g.maxQty = binCap;
      }
    }

    // For PROPORTIONAL mode: calculate scale factor per bin
    const binCategorySums: Record<string, number> = { NG1: 0, NG2: 0, NG3: 0, RST: 0 };
    for (const g of groups.values()) {
      if (binCategorySums[g.ngBox] !== undefined) {
        binCategorySums[g.ngBox] += g.maxQty;
      }
    }

    const binScaleFactors: Record<string, number> = {};
    for (const [box, cap] of Object.entries(binTotals)) {
      const catSum = binCategorySums[box] || 0;
      binScaleFactors[box] = (mode === 'PROPORTIONAL' && catSum > cap && cap > 0) ? (cap / catSum) : 1.0;
    }

    const groupTargetMap = new Map<string, number>();
    for (const [key, g] of groups.entries()) {
      const scale = binScaleFactors[g.ngBox] || 1.0;
      const targetCategoryQty = mode === 'PROPORTIONAL' ? Math.round(g.maxQty * scale) : g.maxQty;
      groupTargetMap.set(key, targetCategoryQty);
    }

    // Balance rounding difference in PROPORTIONAL mode so sum equals binTotals exactly
    if (mode === 'PROPORTIONAL') {
      for (const [box, cap] of Object.entries(binTotals)) {
        if (cap <= 0) continue;
        const boxGroups = Array.from(groups.entries()).filter(([_, g]) => g.ngBox === box);
        if (boxGroups.length === 0) continue;

        const currentSum = boxGroups.reduce((acc, [k]) => acc + (groupTargetMap.get(k) || 0), 0);
        const diff = cap - currentSum;
        if (diff !== 0 && currentSum > 0) {
          // Adjust the largest group
          boxGroups.sort((a, b) => (groupTargetMap.get(b[0]) || 0) - (groupTargetMap.get(a[0]) || 0));
          const largestKey = boxGroups[0][0];
          const currentVal = groupTargetMap.get(largestKey) || 0;
          groupTargetMap.set(largestKey, Math.max(0, currentVal + diff));
        }
      }
    }

    // Assign normalized values
    for (const [key, g] of groups.entries()) {
      const targetCategoryQty = groupTargetMap.get(key) ?? g.maxQty;

      if (g.records.length === 1) {
        const r = g.records[0];
        normalizedResults.push({
          ...r,
          baseCategory: g.baseCat,
          rawNgQty: r.rawNgQty ?? r.ngQty,
          normalizedNgQty: targetCategoryQty,
          ngQty: targetCategoryQty,
        });
      } else {
        // Multiple sub-parameters in same category (e.g. Area, Total Area, X, Y)
        // Distribute targetCategoryQty across sub-parameters proportionally to their raw values
        // so that the sum of sub-parameters equals the deduplicated category maximum!
        const sumSub = g.records.reduce((s, r) => s + (r.rawNgQty ?? r.ngQty), 0);
        let distributed = 0;

        g.records.forEach((r, idx) => {
          const rawVal = r.rawNgQty ?? r.ngQty;
          let assignedQty = 0;
          if (sumSub > 0) {
            if (idx === g.records.length - 1) {
              assignedQty = Math.max(0, targetCategoryQty - distributed);
            } else {
              assignedQty = Math.round(targetCategoryQty * (rawVal / sumSub));
              distributed += assignedQty;
            }
          }
          normalizedResults.push({
            ...r,
            baseCategory: g.baseCat,
            rawNgQty: rawVal,
            normalizedNgQty: assignedQty,
            ngQty: assignedQty,
          });
        });
      }
    }
  }

  return normalizedResults;
}

/**
 * Computes category-level rollups for Pareto and Top Defect rankings
 */
export function getCategorySummaries(
  defects: DefectRecord[],
  sessions: SessionSummary[],
  mode: NormalizationMode = 'DEDUP_MAX'
): CategorySummaryRecord[] {
  const normDefects = normalizeDefectsList(defects, sessions, mode);
  const map = new Map<string, CategorySummaryRecord>();

  normDefects.forEach(d => {
    const cam = d.camera;
    const cat = d.baseCategory || getBaseCategory(d.testItem);
    const key = `${cam}::${cat}`;

    if (!map.has(key)) {
      map.set(key, {
        camera: cam,
        category: cat,
        ngBox: d.ngBox,
        rawQty: 0,
        dedupMaxQty: 0,
        proportionalQty: 0,
        effectiveQty: 0,
        subItemCount: 0,
        subItems: [],
      });
    }

    const entry = map.get(key)!;
    entry.rawQty += (d.rawNgQty ?? d.ngQty);
    entry.effectiveQty += d.ngQty;
    entry.subItemCount += 1;
    entry.subItems.push(d);
  });

  return Array.from(map.values()).sort((a, b) => b.effectiveQty - a.effectiveQty);
}
