import { SessionSummary } from '../types';
import { parseDateTime } from './dateUtils';

export interface ReconciliationResult {
  activeSessions: SessionSummary[];
  rejectedSessions: SessionSummary[];
  duplicateLots: Set<string>; // Set of lot numbers that have duplicate runs (multi-runs)
}

/**
 * Reconcile machine sessions (runs) using the multi-run workflow:
 * - Scenario A: Setup adjustment multi-runs (different times/days). 
 *     Keep only the latest valid setup run, push earlier ones to rejected.
 *     If a run's total is > 5% larger than previous, it is anomalous/invalid and rejected.
 * - Scenario B: Retest/retrun of NG parts.
 *     If a subsequent run's total is close to the previous run's NG + Retest (within 5% margin),
 *     we consolidate them sequentially: Good = Good_prev + Good_curr, NG = NG_curr, Recalculate totals.
 */
export function reconcileSessions(sessions: SessionSummary[]): ReconciliationResult {
  // Group sessions by lotNumber
  const groups: { [lot: string]: SessionSummary[] } = {};
  const duplicateLots = new Set<string>();

  sessions.forEach(s => {
    if (!s.lotNumber || s.lotNumber === '-') return;
    const baseLot = s.lotNumber.split(/[-_]/)[0].trim();
    if (!groups[baseLot]) {
      groups[baseLot] = [];
    }
    groups[baseLot].push(s);
  });

  // Identify duplicate lots (lots with more than 1 run)
  Object.keys(groups).forEach(lot => {
    if (groups[lot].length > 1) {
      duplicateLots.add(lot);
    }
  });

  const activeSessions: SessionSummary[] = [];
  const rejectedSessions: SessionSummary[] = [];

  Object.keys(groups).forEach(lot => {
    const allRuns = [...groups[lot]];
    
    // Sort runs of this lot chronologically
    allRuns.sort((a, b) => {
      const ta = parseDateTime(a.startTime);
      const tb = parseDateTime(b.startTime);
      return ta - tb;
    });

    // 1. Filter out runs with 0 total parts
    const runHistory = allRuns.filter(r => r.total > 0);
    const zeroPartRuns = allRuns.filter(r => r.total === 0);

    // If a lot only has 0-part runs, it's likely noise or failed logs - move all to rejected
    if (runHistory.length === 0) {
        zeroPartRuns.forEach(r => r.lotNumber = lot); // normalize
        rejectedSessions.push(...zeroPartRuns);
        return;
    }

    let currentActive = { ...runHistory[0], lotNumber: lot };
    const historicalDiscarded: SessionSummary[] = [...zeroPartRuns];
    historicalDiscarded.forEach(r => r.lotNumber = lot);

    for (let i = 1; i < runHistory.length; i++) {
      const curr = runHistory[i];
      const T_prev = currentActive.total;
      const T_curr = curr.total;

      // Retest Detection: If filename contains 'retest' or 'rst' or current total is very small compared to prev
      const isExplicitRetest = curr.filename.toUpperCase().includes('RETEST') || 
                               curr.lotNumber.toUpperCase().includes('RETEST') ||
                               curr.filename.toUpperCase().includes('RST');
      
      const isRetestSize = T_curr > 0 && T_curr < T_prev * 0.4;

      if (isExplicitRetest || isRetestSize) {
        // Consolidate retest
        const newOk = currentActive.okQty + curr.okQty;
        const newNg1 = curr.ng1Qty; // Assume latest run has the correct final NG state
        const newNg2 = curr.ng2Qty;
        const newNg3 = curr.ng3Qty;
        const newRetest = curr.retestQty;
        const newTotal = Math.max(T_prev, newOk + newNg1 + newNg2 + newNg3);

        const newYieldRate = newTotal > 0 ? ((newOk / newTotal) * 100).toFixed(2) + '%' : '0.00%';

        historicalDiscarded.push({ ...currentActive });
        currentActive = {
          ...curr,
          lotNumber: lot,
          total: newTotal,
          okQty: newOk,
          ng1Qty: newNg1,
          ng2Qty: newNg2,
          ng3Qty: newNg3,
          retestQty: newRetest,
          yieldRate: newYieldRate
        };
      } else {
        // Non-retest: Replace logic
        // If current run is much larger, it replaces previous setup/test
        if (T_curr > T_prev * 1.5) {
          historicalDiscarded.push({ ...currentActive });
          currentActive = { ...curr, lotNumber: lot };
        } 
        // If current run is much smaller (but not detected as retest above), it's likely a post-prod test
        else if (T_curr < T_prev * 0.5) {
          historicalDiscarded.push({ ...curr, lotNumber: lot });
        }
        // Similar size or slightly larger: keep latest as the "final" state of production
        else {
          historicalDiscarded.push({ ...currentActive });
          currentActive = { ...curr, lotNumber: lot };
        }
      }
    }

    activeSessions.push(currentActive);
    rejectedSessions.push(...historicalDiscarded);
  });

// Sort final sessions chronologically (latest first)
const sortByDateDesc = (a: SessionSummary, b: SessionSummary) => {
  const ta = parseDateTime(a.startTime);
  const tb = parseDateTime(b.startTime);
  return tb - ta;
};

activeSessions.sort(sortByDateDesc);
rejectedSessions.sort(sortByDateDesc);

return {
  activeSessions,
  rejectedSessions,
  duplicateLots
};
}
